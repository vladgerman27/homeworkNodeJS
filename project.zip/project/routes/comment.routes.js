import { Router } from "express"
import addCommentController from '../controllers/comments/addComment.controller.js'
const router = Router()

router.post('/add', add)