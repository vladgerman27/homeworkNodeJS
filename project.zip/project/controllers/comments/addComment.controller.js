import User from '../../models/User.js'
import Post from '../models/Post.js'
import Comment from '../models/Comments.js'

export default async (req,res) => {
    try {
        const user_id = req.user.user_id

        const { comment = null, post_id = null } = req.body
        if (!comment) {
            return res.status(400).json({message: 'Doesnt exist comments'})
        }

        const post = await Post.findById(post_id)
        if (!post) {
            return res.status(400).json({message: 'Doesnt exist post'})
        }

        const newComment = new Comment({
            body: comment,
            created_at: Date.now(),
            authir: user_id
        })

        const addedComment = await newComment.save()

        const updatedComments = [...post.comments, comment]

        await Post.findByIdAndUpdate(post._id, {comments: updatedComments}, {rawResult: true}, (err) => {
            if (err) {
                return res.status(500).json({ message: ''})
            }
            return res.status(201).json({ message: ''})
        })

    } catch (e) {
        console.log(e)
        res.status(500).json({message: 'Error 500'})  
    }
}