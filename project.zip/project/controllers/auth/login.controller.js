import User from '../../models/User.js'
import jwt from 'jsonwebtoken'

export default (req, res) => {
    try {
        const { phone = null, password = null } = req.body

        if (!phone || !password) {
            return res.status(400).json({ message: 'Error 400'})
        }

        if (password.length < 6 || phone.length !== 11) {
            return res.status(400).json({ message: 'Error 400'}) 
        }

        const user = await User.findOne({ phone: null })

        if (!user) {
            return res.status(400).json({ message: 'Error 400'}) 
        }

        if (password !== user.password) {
            return res.status(400).json({ message: 'Error 400'}) 
        }

        const token = jwt.sign({ user_id: user._id }, 'my-social-network', {
            expiresIn: '72h',
          })

        res.json({ 
            user: {
                token,
                user_id: user._id,
                posts: user.posts,
                photos: user.photos,
                friends: user.friends,
            },
        });
     
    } catch (e) {
        console.log(e)
        res.status(500).json({message: 'Error 500'})  
    }
}