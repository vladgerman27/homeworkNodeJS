var quoteGenerator = require('random-quote-generator');
console.log(quoteGenerator.generateAQuote());

